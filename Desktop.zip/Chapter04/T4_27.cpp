/*FileName£ºT4_27.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Binary to decimal
*/
#include<iostream>
using namespace std;
int main()
{
    cout<<"请输入一个二进制数"<<endl;
    int a,b=0,c=1;
    cin>>a;
    while(a>0)
    {
        b=b+a%10*c;
        c=c*2;
        a=a/10
    }
    cout<<b<<endl;
    return 0;
}
