/*FileName��T4_15.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Sales commission calculator
*/
 #include <iostream>

#include <iomanip>

using namespace std;

int main()
{
    int n;
    cout <<"Enter sales in dollars (-1 to end):"<<endl;
    cin >>n;
    while(n!=-1){
        cout <<"Salary is : $";
        cout <<fixed<<setprecision(2)<<200+n*0.09<<endl;
        cout <<"\n"<<endl;
    cout <<"Enter sales in dollars (-1 to end):"<<endl;
    cin >>n;
    }
    return 0;
}

