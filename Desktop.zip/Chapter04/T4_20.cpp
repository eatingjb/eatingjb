/*FileName��T4_20.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:change the16
*/
#include<iostream>
using namespace std;
int main()
{
   int n,i=1,a=0,b=0;
    while(i<=10){
    cout << "Enter result (1=pass,2=fail):" << endl;
    cin>>n;
    if(n==1){a++;i++;}
    if(n==2){b++;i++;}
    }
    cout<<"Passed "<<a<<endl;
    cout<<"Failed "<<b<<endl;
    return 0;

}
