/*FileName��T4_17
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Calculate the largest of the ten numbers
*/
#include<iostream>
using namespace std;
int main()
{
    int counter, number, largest;
    cin >> number;
    counter = 1;
    while (counter < 10)
    {
        largest = number;
        cin >> number;
        if (number > largest)
        {
            largest = number;
        }
        else { largest = largest; }
        counter++;
    }
    cout << largest;
    return 0;
}
