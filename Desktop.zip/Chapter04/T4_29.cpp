/*FileName��T4_29.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Multiple of infinite loop two
*/
#include<iostream>
using namespace std;
int main()
{
    int a = 2;
    while (true)
    {
        cout << a << " ";
        a=a * 2;
    }
    return 0;
}
