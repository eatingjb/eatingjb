/*FileName��T4_17
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Find the two largest numbers from the ten numbers
*/
#include<iostream>
using namespace std;
int main()
{
    int counter, number, largest,largest2 = -999999999;
    counter = 1;
    while (counter <= 10)
    {
        cin >> number;
        if (counter == 1)
        {
            largest = number;
        }
        else
        {
            if (number >= largest) { largest2 = largest; largest = number; }
            else if (number > largest2) largest2 = number;
        }
        counter++;
    }
    cout << largest <<" " << largest2 << endl;
    return 0;
}
