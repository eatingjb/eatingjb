/*FileName��T4_25.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Hollow square
*/
#include<iostream>
using namespace std;
int main()
{
    int i, n,j;
    cin >> n;
    for (i = 1; i <= n; i++)
    {
        cout << "*" ;
    }
    cout << endl;
    for (i = 2; i <n; i++)
    {
        for (j = 1; j <= n; j++)
        {
            if (j ==1 || j == n)
            {
                cout << "*";
            }
            else cout << " ";
        }
        cout << endl;
    }
    for (i = 1; i <= n; i++)
    {
        cout << "*";
    }
}
