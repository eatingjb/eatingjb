/*FileName��T4_14.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Credit limit problem
*/
#include <iostream>

#include <iomanip>

using namespace std;

int main()
{
    int a;
    double b,c,d,e,n;
    cout <<"Enter account number (or -1 to quit) :"<<endl;
    cin >>a;
    while (a!=-1){
    cout <<"Enter beginning balance :"<<endl;
    cin >>b;
    cout <<"Enter total charges :"<<endl;
    cin >>c;
    cout <<"Enter total credits :"<<endl;
    cin >>d;
    cout <<"Enter credit limit:"<<endl;
    cin >>e;
    cout <<"New balance is :"<<endl;
    cout <<b+c-d<<endl;
    n=b+c-d-e;
    if (n>0){
    cout <<"Account :"<<a<<endl;
    cout <<"Credit limit :"<<e<<endl;
    cout <<"Balance :"<<b+c-d<<endl;
    cout <<"Credit Limit Exceeded.\n"<<endl;}
    cout <<"Enter account number (or -1 to quit) :"<<endl;
    cin >>a;}


    return 0;
}
