/*FileName��T4_36.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:data encryption
*/
#include<iostream>
using namespace std;
int main()
{
	cout << "��������λ��������" << endl;
	int a, m, n, p, q, t;
	cin >> a;
	m = a % 10;
	n = a / 10 % 10;
	p = a / 100 % 10;
	q = a / 1000 % 10;
	if (m < 7) m = m + 3;
	else  m = m - 7;
	if (n < 7) n = n + 3;
	else  n = n - 7;
	if (p < 7) p = p + 3;
	else  p = p - 7;
	if (q < 7) q = q + 3;
	else q = q - 7;
	t = n * 1000 + m * 100 + q * 10 + p;
	cout << "ԭ����Ϊ" << t;
	return 0;
}
