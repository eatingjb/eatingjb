/*FileName��T4_16.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Salary calculator
*/

   #include <iostream>

#include <iomanip>

using namespace std;

int main()
{
    int n,a;
    cout <<"Enter hours worked (-1 to quit):"<<endl;
    cin >>n;
    while(n!=-1){
        cout <<"Enter hourly rate of the employee ($00.00):"<<endl;
        cin >>a;
        if (n<40){
            cout <<fixed<<setprecision(2)<<"Salary is $"<<10*n<<"\n"<<endl;
        }else {cout <<fixed<<setprecision(2)<<"Salary is $"<<400+15*(n-40)<<"\n"<<endl;}
        cout <<"Enter hours worked (-1 to quit):"<<endl;
        cin >>n;
    }
    return 0;
}

