/*FileName£ºT4_13.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Calculate the number of miles per gallon the driver travels each time
*/
#include<iostream>
using namespace std;
int main()
{
    double a, b, p = 0, q = 0;
    cout << "请输入出车加油量：";
    cin >> a;
    cout << "请输入每加仑英里数:";
    cin >> b;
    while (a != -1)
    {
        p = p + a;
        q = q + b;
        cout << "Enter miles driven(-1 to quit):" << a << endl;
        cout << "Enter gallons used:" << b << endl;
        cout << "MPG this trip:" << a / b << endl;
        cout << "Total MPG:" << p / q << endl;
        cout << "请输入出车加油量：";
        cin >> a;
        cout << "请输入每加仑英里数:";
        cin >> b;
    }
    cout << "Enter the miles used(-1 to quit):-1";
    return 0;
}
