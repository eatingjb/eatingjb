/*FileName��T6_53.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Function templates "maximum"
*/
#include<bits/stdc++.h>
using namespace std;
int minimum(int a,int b)
{
	if(a>b) return a;
	else return b;
}
char minimum(char a,char b)
{
	if('a'>'b') return a;
	else return b;
}
int main()
{
	int a,b;
	cin>>a>>b;
	cout<<minimum(a,b)<<endl;
	char c,d;
	cin>>c>>d;
	cout<<minimum(c,d)<<endl;
   return 0;
}
