/*FileName��T6_37.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Fibonacci
*/
#include<bits/stdc++.h>
using namespace std;
int Fibonacci(int n)
{
	int a=1,b=1,c;
	if(n==1||n==2) return 1;
	else
	{
		n=n-2;
		while(n--)
	    {
		   c=a+b;
		   a=b;
		   b=c;
	    }
	       return c;
	}

}
int main()
{
	int n;
	cin>>n;
	cout<<Fibonacci(n);
   return 0;
}

