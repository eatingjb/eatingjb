/*FileName��T6_59.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Monitor student performance
*/

#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a,b,c,ans,pro,sum1=0,sum2=0,sum3=0;
	srand(static_cast<unsigned int>(time(NULL)));
	while(1)
	{
		a=rand()%9+1;
	    b=rand()%9+1;
	
	    cout<<"How much is "<<a<<" times "<<b;
	    cout<<endl;
	    cin>>ans;
	    pro=a*b;
		if(ans==pro) 
	    {
	    	c=rand()%4+1;
		    switch (c)
		    {
		    	case 1:cout<<"Very good!";break;
		    	case 2:cout<<"Excellent!";break;
		    	case 3:cout<<"Nice work!";break;
		    	case 4:cout<<"Keep up the good work!";break;
		    	default: break;
			}
			cout<<endl;
			sum1+=1;
			sum2+=1;
			if(sum1==10) break;
		    return main();
	    }
	    else 
	    {
	    	c=rand()%4+1;
		    switch(c)
		    {
		    	case 1:cout<<"No.Please try again.";break;
		    	case 2:cout<<"Wrong.Try once more.";break;
		    	case 3:cout<<"Don't give up!";break;
		    	case 4:cout<<"No.Keep trying.";break;
		    	default: break;
			}
			sum1+=1;
			sum3+=1;
			if(sum1==10) break;
	     	return main();
	    } 
	}
	if((sum2/sum1)*10>7) cout<<"Congratulations,you are ready to go to the next level!";
	else cout<<"Please ask your teacher for extra help.";
   return 0;
}
