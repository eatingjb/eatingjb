/*FileName��T6_45.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Modify the program
*/
#include<bits/stdc++.h>
using namespace std;
int mystery(int,int);
int judgment(int a)
{
	if(a>0) return a;
	else 
	{
		cout<<"your input the y is wrong,please input the y else"<<endl;
		cin>>a;
		return judgment(a);
	}
}
int main()
{
		int x;
		int y;
		cout<<"Enter two integers:";
		cin>>x>>y;
		y=judgment(y);
		cout<<"The result is"<<mystery(x,y)<<endl;
	}
	int mystery(int a,int b)
	{
		if(1==b) return a;
		else return a+mystery(a,b-1); 
	}
   

