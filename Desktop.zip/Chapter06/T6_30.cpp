/*FileName��T6_30.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Number reverse
*/
#include<iostream>
using namespace std;
void numberReverse(int a)
{
	int n,sum=0,p;
	n=a;
	while(n>0)
	{
		n=n/10;
		sum+=1;
	}
	int arr[sum];
	for(int i=0;i<sum;i++)
	{
		p=a%10;
		a=a/10;
		arr[i]=p;
	}
	for(int j=0;j<sum;j++)
	{
		cout<<arr[j];
	}
}
int main()
{
	int a;
	cin>>a;
	numberReverse(a);
   return 0;
}
