/*FileName��T6_27.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Find the minimum number
*/
#include<iostream>
using namespace std;
double findMinimum(double a,double b,double c)
{
	int min;
	if(a>b) min=b;
	else min=a;
	if(c<min) min=c;
	return min;
}
int main()
{
	int a,b,c;
	cin>>a>>b>>c;
	cout<<findMinimum(a,b,c);
   return 0;
}
