/*FileName��T6_33.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Flip a coin
*/
#include<bits/stdc++.h>
using namespace std;
int flip(int a)
{
 	a=rand()%2;
 	if(1==a) return 1;
 	else return 0;
}
int main()
{
 	int a,n;
 	while(1)
 	{
		cout<<"������Ӳ�ҵĴ���������-1ֹͣ): ";
  		cin>>n;
  		if(n==-1) break; 
  		for(int i=1;i<=n;i++)
   	    {
        	cout<<flip(a)<<" ";
     	}
  		cout<<endl;
}
   return 0;
}
