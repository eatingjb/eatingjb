/*FileName��T6_24.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Digital separation
*/
#include<iostream>
using namespace std;
int main()
{
	int a,n,sum=0,b;
	cin>>a;
	n=a;
	while(n>0)
	{
		n=n/10;
		sum+=1;
	}
	int arr[sum];
	for(int i=sum-1;i>=0;i--)
	{
		b=a%10;
		a=a/10;
		arr[i]=b;
	}
	for(int j=0;j<sum;j++)
	{
		cout<<arr[j]<<" ";
	}
   return 0;
}
