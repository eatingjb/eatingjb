/*FileName��T6_12.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Parking fee calculation
*/
#include<iostream>
#include<cmath>
using namespace std;
double calculateCharges(double n)
{
	if(n<=3) return 2;
	else if(n>3&&n<=19) return 2+ceil(n-3)*0.5;//�ڶ������ü��㲻��2.5 
	else return 10;
}
int main()
{
	double n,sum1=0,sum2=0;
	
	for(int i=1;i<=3;i++)
	{
		cin>>n;
		if(1==i) cout<<"Car\tHours\tCharge"<<endl;
		cout<<i<<"\t"<<n<<"\t"<<calculateCharges(n)<<endl;
		sum1=sum1+n;
		sum2=sum2+calculateCharges(n);
	}
	cout<<"TOTAL\t"<<sum1<<"\t"<<sum2;
   return 0;
}

