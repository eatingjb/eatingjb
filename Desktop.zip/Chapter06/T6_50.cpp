/*FileName��T6_50.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Pass by value vs. pass by reference
*/
#include<bits/stdc++.h>
using namespace std;
int tripleByValue(int a)
{
	return 3*a;
}
int tripleByReference(int &a)
{
	return 3*(a);
}
int main()
{
	int a;
	cin>>a;
	
	cout<< tripleByReference(a)<<endl;
	cout<<tripleByValue(a);
   return 0;
}
