/*FileName��T6_26.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Celsius and Fahrenheit
*/
#include<iostream>
using namespace std;
double celsiusToFahrenheit(double c1)
{
	double f1;
	f1=c1*1.8+32;
	return f1;
}
double fahrenheitTocelsius(double f2)
{
	double c2;
	c2=(f2-32)/1.8;
	return c2;
}
int main()
{
	cout<<"���϶�\t"<<"���϶�"<<endl;
	for(double c1=0;c1<=100;c1++)
	{
		cout<<c1<<"\t"<<celsiusToFahrenheit(c1)<<endl;
	 } 
	 cout<<endl;
	 cout<<"���϶�\t"<<"���϶�"<<endl; 
	 for(double f2=32;f2<=212;f2++)
	{
		cout<<f2<<"\t"<<fahrenheitTocelsius(f2)<<endl;
	 } 
   return 0;
}
