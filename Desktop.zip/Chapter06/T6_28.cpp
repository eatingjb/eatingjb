/*FileName��T6_28.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Completion
*/
#include<iostream>
using namespace std;
int isperfect(int a)
{
	int sum=0;
	for(int i=1;i<a;i++)
	{
		for(int j=1;j<i;j++)
		{
			if(a==i*j) sum=sum+i+j;
		}
	}
	return sum+1;
}
int main()
{
	for(int k=1;k<=1000;k++)
	{
		if(k==isperfect(k))
		{
			cout<<k<<" ";
		}
	}
	
   return 0;
}
