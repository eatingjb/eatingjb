/*FileName��T6_25.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Counted in seconds
*/
#include<iostream>
using namespace std;
int timeDifference(int hour ,int minute,int second)
{
	return hour*3600+minute*60+second;
}
int main()
{
	int hour,minute,second;
	cin>>hour>>minute>>second;
	cout<<timeDifference(hour ,minute,second);
   return 0;
}
