/*FileName��T6_14.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Specific decimal rounging of numbers
*/
#include<iostream>
#include<cmath>
using namespace std;
roundToInteger(double number)
{
	return floor(number+0.5);
}
roundToTenths(double number)
{
	return floor(number*10+0.5)/10;
}
roundToHundredths(double number)
{
	return floor(number*100+0.5)/100;
}
roundToThousandths(double number)
{
	return floor(number*1000+0.5)/1000;
}
int main()
{
   double n;
   cin>>n;
   cout<<n<<" "<<roundToInteger(n)<<" "<<roundToTenths(n)<<" "<<roundToHundredths(n)<<" "<<roundToThousandths(n);
   return 0;
}

