/*FileName��T6_20.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:multiple
*/
#include<iostream>
using namespace std;
int multiple(int a,int b)
{
	if(0==a%b) return true;
	else return false;
}
int main()
{
	int a,b;
	for(int i=1;i<=10;i++)
	{
	   cin>>a>>b;
	   cout<<multiple(a,b)<<endl;
    }
    return 0;
}
