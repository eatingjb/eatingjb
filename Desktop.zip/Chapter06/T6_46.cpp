/*FileName��T6_ 46.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
	double a,b;
	cin>>a>>b;
	cout<<ceil(a)<<endl;
	cout<<cos(a)<<endl;
	cout<<fabs(a)<<endl;
	cout<<floor(a)<<endl;
	cout<<fmod(a,b)<<endl;
	cout<<log(a)<<endl;
	cout<<log(a)<<endl;
	cout<<log10(a)<<endl;
	cout<<pow(a,b)<<endl;
	cout<<sin(a)<<endl;
	cout<<sqrt(a)<<endl;
	cout<<tan(a)<<endl;
   return 0;
}
