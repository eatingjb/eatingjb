/*FileName��T6_36.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Recursive power calculation
*/
#include<bits/stdc++.h>
using namespace std;
int power(int base,int exponent)
{
	if(exponent) return base*power(base,exponent-1);
	return 1; 
}
int main()
{
	int n,m;
	cin>>n>>m;
	cout<<power(n,m)<<endl;
	return 0;
}
