/*FileName��T6_49.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Circle area calculation
*/
#include<bits/stdc++.h>
using namespace std;
inline double circleArea(double a)
{
	return 3.14*a*a;
}
int main()
{
	cout<<"������Բ�İ뾶"<<endl;
	double r;
	cin>>r;
	cout<<circleArea(r);
   return 0;
}
