/*FileName��T6_61.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Problem classification
*/
#include <iostream>
#include<cstdlib>//ʹ��rand�������������
#include<ctime>//ʹ��stand��β��ظ�����
#include<cmath>
using namespace std;

int main()
{int a,b,c,d,i=10,Win=0,grade,num,choice,fix,x;
cout<<"Please input your choice (��+��=1,��-��=2,��*��=3,��/��=4,max=5)"<<endl;
cin>>choice;
cout<<"Please input the difficult grade:";
cin>>grade;
while(1){i=10;
while(i){
   srand(time(0));
   num=pow(10,grade);
   a=rand()%(num); 
   b=rand()%(num);
   d=rand()%4;
if(1==choice)
    {x=a+b;cout<<"How much is "<<a<<" add "<<b<<"?"<<endl;}
if(2==choice)
    {x=a-b;cout<<"How much is "<<a<<" subtract "<<b<<"?"<<endl;}
if(3==choice)
    {x=a*b;cout<<"How much is "<<a<<" times "<<b<<"?"<<endl;}
if(4==choice)
    {x=a/b;cout<<"How much is "<<a<<" divide "<<b<<"?"<<endl;}
if(5==choice){
    fix=rand()%4;
    if(1==fix)
    {x=a+b;cout<<"How much is "<<a<<" add "<<b<<"?"<<endl;}
    if(2==fix)
    {x=a-b;cout<<"How much is "<<a<<" subtract "<<b<<"?"<<endl;}
    if(3==fix)
    {x=a*b;cout<<"How much is "<<a<<" times "<<b<<"?"<<endl;}
    if(4==fix)
    {x=a/b;cout<<"How much is "<<a<<" divide "<<b<<"?"<<endl;}
}cin>>c;
   if(c==x){Win++;
       switch(d){
        case 1:
            cout<<"Very good!"<<endl;break;
        case 2:
            cout<<"Excellent!"<<endl;break;
        case 3:
            cout<<"Nice work!"<<endl;break;
        case 4:
            cout<<"Keep up the good work!"<<endl;break;}}
   else  {switch(d){
        case 1:
            cout<<"No. Please try again!"<<endl;break;
        case 2:
            cout<<"Wrong. Try once more!"<<endl;break;
        case 3:
            cout<<"Don't give up!"<<endl;break;
        case 4:
            cout<<"No. Keep trying."<<endl;break;}}
            i--;
            }if (Win>7)cout<<"Congratulations,your teacher for extra help.\n"<<endl;
            else cout<<"Please ask your teacher for extra help\n"<<endl;
            cout<<"***********next***********"<<endl;}
    return 0;
}
