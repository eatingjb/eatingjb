/*FileName��T6_29.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:prime number
*/
#include<iostream>
#include<cmath>
using namespace std;
void primeNumber(int a)
{
	int p=1;
	for(int i=2;i<=sqrt(a);i++)
	{
		if(0==a%i) {
			p=p-1;break;
		}
		
	}
	if(1==p) cout<<a<<" ";
}
int main()
{
	for(int j=2;j<=10000;j++)
	{
		primeNumber(j);
		
	}
   return 0;
}
