/*FileName��T6_57.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Computer-aided teaching
*/
#include<bits/stdc++.h>
using namespace std;


int main()
{
	int a,b,ans,pro;
	srand(static_cast<unsigned int>(time(NULL)));
	a=rand()%9+1;
	b=rand()%9+1;
	cout<<"How much is "<<a<<" times "<<b;
	cout<<endl;
	cin>>ans;
	pro=a*b;
	while(1)
	{
		if(ans==pro) 
	    {
		    cout<<"Very good!";
		    return 0;
	    }
	    else 
	    {
		    cout<<"No.Please try again.";
	     	cin>>ans;
	    } 
	}
   return 0;
}
