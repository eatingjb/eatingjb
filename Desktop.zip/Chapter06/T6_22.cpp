/*FileName��T6_22.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:A square pattern of stars
*/
#include<iostream>
using namespace std;
int main()
{
	int side;
	cin>>side;
	for(int i=1;i<=side;i++)
	{
		for(int j=1;j<=side;j++)
		{
			cout<<"*";
		}
		cout<<endl;
	}
   return 0;
}
