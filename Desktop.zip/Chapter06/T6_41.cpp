/*FileName��T6_41.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:The greatest common divisor of recursion
*/
#include<bits/stdc++.h>
using namespace std;
int gcd(int a,int b)
{
	if(a%b==0) return b;
	else return gcd(b,a%b);
}
int main()
{
	int a,b;
	cin>>a>>b;
	cout<<gcd(a,b);
   return 0;
}
