/*FileName��T6_21.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:even
*/
#include<iostream>
using namespace std;
int iseven(int n)
{
	if(0==n%2) return true;
	else return false;
}
int main()
{
	int n;
	cin>>n;
	cout<<iseven(n)<<endl;
   return 0;
}
