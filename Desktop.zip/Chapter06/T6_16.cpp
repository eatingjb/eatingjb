/*FileName��T6_16.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:random number
*/
#include<iostream>
#include<cstdlib>
#include<ctime>
using namespace std;
int main()
{
	int n;
	srand(time(0));
	n=rand();
	cout<<n;
   return 0;
}

