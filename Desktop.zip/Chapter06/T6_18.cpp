/*FileName��T6_18.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Exponentiation calculation
*/
#include<iostream>
using namespace std;
double integerPower(double base ,int exponent)
{
	double n;
	n=base;
	for(int i=1;i<exponent;i++)
	{
		base=base*n;
	}
	return base;
}
int main()
{
	double base;
	int exponent;
	cin>>base>>exponent;
	cout<<integerPower(base,exponent);
   return 0;
}
