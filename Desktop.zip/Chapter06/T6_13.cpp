/*FileName��T6_13.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Integer rounding of numbers
*/
#include<iostream>
#include<cmath>
using namespace std;
int main()
{
	double x,y;
	cout<<"������ʮ����"<<endl; 
	for(int i=1;i<=10;i++)
	{
		cin>>x;
		y=floor(x+0.5);
		cout<<x<<"\t"<<y<<endl;
	}
   return 0;
}

