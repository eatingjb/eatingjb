/*FileName��T6_19.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Right triangle bevel calculation
*/
#include<iostream>
#include<cmath>
using namespace std;

double hypontenuse(double m,double n)
{
	return sqrt((m*m)+(n*n));
}
int main()
{
	double m,n;
	cin>>m>>n;
	cout<<hypontenuse(m,n);
   return 0;
}
