/*FileName��T6_31.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:greatest common divisor
*/
#include<iostream>
using namespace std;
int gcd(int a,int b)
{
	int max=0;
	for(int i=1;i<=a;i++)
	{
		if(0==a%i&&0==b%i)
		{
			if(i>max)
			{
				max=i;
			} 
		}
	}
	return max;
}
int main()
{
	int a,b;
	cin>>a>>b;
	cout<<gcd(a,b);
   return 0;
}
