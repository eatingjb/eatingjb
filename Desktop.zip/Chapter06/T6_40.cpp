/*FileName��T6_40.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Recursive visualization
*/
#include<bits/stdc++.h>
using namespace std;
int factorial(int n)
{
	if(n==0||n==1) return 1;
	else return n*factorial(n-1);
}
int main()
{
	int n;
	cin>>n;
	cout<<factorial(n);
   return 0;
}
