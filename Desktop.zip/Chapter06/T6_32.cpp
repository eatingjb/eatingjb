/*FileName��T6_32.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Grade points for grades
*/
#include<iostream>
using namespace std;
int qualityPoints(int a)
{
    if(a>=90&&a<=100) return 4;
    else if(a>=80&&a<=89) return 3;
    else if(a>=70&&a<=79) return 2;
    else if(a>=60&&a<=69) return 1;
    else return 0;
}
int main()
{
	int a;
	cin>>a;
	cout<<qualityPoints(a);
   return 0;
}
