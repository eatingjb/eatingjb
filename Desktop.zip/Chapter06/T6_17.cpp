/*FileName��T6_17.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:ramdon number
*/
#include<bits/stdc++.h>


using namespace std;
int main()
{
	default_random_engine engine(static_cast<unsigned int>time(0));
	uniform_int_distribution<unsigned int> randomInt(2,10);
   return 0;
}
