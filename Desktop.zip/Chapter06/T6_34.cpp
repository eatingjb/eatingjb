/*FileName��T6_34.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Guess the numbers game
*/
#include<bits/stdc++.h>
using namespace std;
void compareSize()
{
	int a,b;
	srand(time(0));
	a=rand()%1000+1;
	cout<<"I have a number between 1 and 1000."<<endl;
	cout<<"Can you guess my number?"<<endl;
	cout<<"Please type your first guess."<<endl;
	for(int i;i<=10000;i++)
	{
		cin>>b;
		if(a==b) 
		{
			cout<<"Excellent! You guessed the number!"<<endl;
	        cout<<"Would you like to play again(y or n)?";
	        char ch;
	        cin>>ch;
	        if(ch=='y') compareSize();
	        if(ch=='n') break;
		}
		if(b<a) 
	    {
	       cout<<"Too low. Try again."<<endl;
	       
        }
        if(b>a)
        {
    	    cout<<"Too high. Try again."<<endl;
	    }
	}
}
int main()
{
    compareSize();
	
	
   return 0;
}
