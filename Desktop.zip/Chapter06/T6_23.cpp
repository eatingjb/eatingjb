/*FileName��T6_23.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:A square pattern of arbitrary symbols
*/
#include<iostream>
using namespace std;
int main()
{
	char fillCharacter;
	int side;
	cin>>side;
	cin>>fillCharacter;
	for(int i=1;i<=side;i++)
	{
		for(int j=1;j<=side;j++)
		{
			cout<<fillCharacter;
		}
		cout<<endl;
	}
   return 0;
}
