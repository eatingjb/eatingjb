/*FileName��T6_58.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Eliminate student fatigue
*/
#include<bits/stdc++.h>
using namespace std;


int main()
{
	int a,b,c,ans,pro;
	srand(static_cast<unsigned int>(time(NULL)));
	a=rand()%9+1;
	b=rand()%9+1;
	
	cout<<"How much is "<<a<<" times "<<b;
	cout<<endl;
	cin>>ans;
	pro=a*b;
	while(1)
	{
		
		if(ans==pro) 
	    {
	    	c=rand()%4+1;
		    switch (c)
		    {
		    	case 1:cout<<"Very good!";break;
		    	case 2:cout<<"Excellent!";break;
		    	case 3:cout<<"Nice work!";break;
		    	case 4:cout<<"Keep up the good work!";break;
		    	default: break;
			}
		    return 0;
	    }
	    else 
	    {
	    	c=rand()%4+1;
		    switch(c)
		    {
		    	case 1:cout<<"No.Please try again.";break;
		    	case 2:cout<<"Wrong.Try once more.";break;
		    	case 3:cout<<"Don't give up!";break;
		    	case 4:cout<<"No.Keep trying.";break;
		    	default: break;
			}
	     	cin>>ans;
	    } 
	}
   return 0;
}
