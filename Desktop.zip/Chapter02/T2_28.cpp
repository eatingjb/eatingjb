/*FileName��T2_28
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Decompose each digit of a five digit number
*/
#include<iostream>
using namespace std;
int main()
{
   cout<<"������һ����λ��"<<endl;
   char a,b,c,d,e;
   cin>>a>>b>>c>>d>>e;
   cout<<a<<"   "<<b<<"   "<<c<<"   "<<d<<"   "<<e<<endl;
   return 0;
}
