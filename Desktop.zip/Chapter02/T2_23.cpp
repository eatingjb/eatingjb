/*FileName��T2_23
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Enter five numbers and output the maximum and minimum of them
*/
#include<iostream>
using namespace std;
int main()
{
    int a, b, c, d, e, max1, min1, max2, min2, max3, min3, max, min;
    cin >> a >> b >> c >> d >> e;
    if (a > b)
    {
        max1 = a;
        min1 = b;
    }
    else
    {
        max1 = b;
        min1 = a;
    }
    if (c > d)
    {
        max2 = c;
        min2 = d;
    }
    else
    {
        max2 = c;
        min2 = d;
    }
    if (max1 > max2)
    {
        max3 = max1;
    }
    else max3 = max2;
    if (min1 > min2)
    {
        min3 = min2;
    }
    else min3 = min1;
    if (e > max3) max = e;
    else max = max3;
    if (e < min3) min = e;
    else min = min3;
    cout << "������Ϊ" << max<<endl;
    cout << "��С����Ϊ" << min<<endl;
    return 0;

}
