/*FileName��T2_19.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Find the maximum and minimum of the product of the sum average of three integers
*/
#include<iostream>
using namespace std;
int main()
{
	cout << "Input three different integers:" << endl;
	int a, b, c, d, e;
	cin >> a;
	cin >>b;
	cin >> c;
	if (a > b) d = b;
	else d = a;
	if (c > d) d=d;
	else d = c;
	if (a > b) e = a;
	else e = b;
	if (c > e) e = c;
	else e=e;
	cout << "Sum is" << " " << a + b + c << endl;
	cout << "Average is" << " " << (a + b + c) / 3 << endl;
	cout << "Product is" << " " << a * b * c << endl;
	cout << "Smallest is" << " " << d << endl;
	cout << "Largest is" << " " << e << endl;
	return 0;
}
