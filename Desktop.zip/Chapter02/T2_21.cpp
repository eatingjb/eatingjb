/*FileName��T2_21.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Write a program to output rectangular, elliptical arrows and diamonds
*/
#include<iostream>
using namespace std;
int main()
{
   cout<<"*********"<<endl;
   cout<<"*       *"<<endl;
   cout<<"*       *"<<endl;
   cout<<"*       *"<<endl;
   cout<<"*       *"<<endl;
   cout<<"*       *"<<endl;
   cout<<"*       *"<<endl;
   cout<<"*       *"<<endl;
   cout<<"*********"<<endl;
   cout<<"   ***   "<<endl;
   cout<<" *     * "<<endl;
   cout<<"*       *"<<endl;
   cout<<"*       *"<<endl;
   cout<<"*       *"<<endl;
   cout<<"*       *"<<endl;
   cout<<"*       *"<<endl;
   cout<<" *     * "<<endl;
   cout<<"   ***   "<<endl;
   cout<<"    *    "<<endl;
   cout<<"   ***   "<<endl;
   cout<<"  *****  "<<endl;
   cout<<"    *    "<<endl;
   cout<<"    *    "<<endl;
   cout<<"    *    "<<endl;
   cout<<"    *    "<<endl;
   cout<<"    *    "<<endl;
   cout<<"    *    "<<endl;
   cout<<"    *    "<<endl;
   cout<<"    *    "<<endl;
   cout<<"   * *   "<<endl;
   cout<<"  *   *  "<<endl;
   cout<<" *     * "<<endl;
   cout<<"*       *"<<endl;
   cout<<" *     * "<<endl;
   cout<<"  *   *  "<<endl;
   cout<<"   * *   "<<endl;
   cout<<"    *    "<<endl;
   return 0;

}
