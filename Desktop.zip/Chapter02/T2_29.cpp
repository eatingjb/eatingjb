/*FileName��T2_29.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Outputs the sum of squares and cubes of integers 0 to 10
*/
#include<iostream>
using namespace std;
int main()
{
   cout<<"integer\tsquare\tcube"<<endl;
   cout<<"0\t0\t0"<<endl;
   cout<<"2\t4\t8"<<endl;
   cout<<"3\t9\t27"<<endl;
   cout<<"4\t16\t64"<<endl;
   cout<<"5\t25\t125"<<endl;
   cout<<"6\t36\t216"<<endl;
   cout<<"7\t49\t343"<<endl;
   cout<<"8\t64\t512"<<endl;
   cout<<"9\t81\t729"<<endl;
   cout<<"10\t100\t1000"<<endl;
   return 0;
}
