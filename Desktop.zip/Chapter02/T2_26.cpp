/*FileName��T2_26
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:There are two ways to display the chessboard pattern
*/
#include<iostream>
using namespace std;
int main()
{
	cout << "* * * * * * * *" << endl;
	cout << " * * * * * * * *" << endl;
	cout << "* * * * * * * *" << endl;
	cout << " * * * * * * * *" << endl;
	cout << "* * * * * * * *" << endl;
	cout << " * * * * * * * *" << endl;
	cout << "* * * * * * * *" << endl;
	cout << " * * * * * * * *" << endl;
	cout << "��Ϊ�ø��������ʾͼ��"<<endl;
	for (int i = 1; i < 5; i++)
	{
		cout << "* * * * * * * *" << endl;
		cout << " * * * * * * * *" << endl;
	}
	return 0;
}
