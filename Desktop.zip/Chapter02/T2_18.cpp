/*FileName��T2_18.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Compare the size of two numbers
*/
#include<iostream>
using namespace std;
int main()
{
   int a,b;
   cin>>a>>b;
   if(a==b)
   {
       cout<<"These numbers are equal"endl;
   }
   if(a>b)
   {
       cout<<a<<"is large"<<endl;
   }
   if(a<b)
   {
       cout<<b<<"is large"<<endl;
   }
   return 0;
}
