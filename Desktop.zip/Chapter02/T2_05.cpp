/*FileName：T2_02.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Calculate the product of three numbers
*/
#include<iostream>
using namespace std;
int main()
{
    cout<<"ÇëÊäÈëÈý¸öÊý"<<endl;
   int a,b,c;
   cin>>a>>b>>c;
   cout<<a*b*c<<endl;
   return 0;
}
