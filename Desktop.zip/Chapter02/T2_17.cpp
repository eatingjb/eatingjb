/*
FileName��T2_17.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:There are many ways to output 1 to 4
*/
#include<iostream>
using namespace std;
int main()
{
    /*��Ϊ��һС��*/
   int a,b,c,d;
   cin>>a>>b>>c>>d;
   cout<<a<<""<<b<<""<<c<<""<<d<<endl;
   return 0;
    /*��Ϊ�ڶ�С��*/
   int a,b,c,d;
   cin>>a;
   cin>>b;
   cin>>c;
   cin>>d;
   cout<<a<<""<<b<<""<<c<<""<<d<<endl;
   return 0;
    /*��Ϊ����С��*/
   int a,b,c,d;
   cin>>a>>b>>c>>d;
   cout<<a<<""<<b<<""<<c<<""<<d<<endl;
   return 0;
}
