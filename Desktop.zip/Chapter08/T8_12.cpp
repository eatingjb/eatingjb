/*FileName��T8_12.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Tortoise and rabbit racing
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a,b;
	srand(time(NULL));
	cout<<"BANG!!!!!"<<endl;
	cout<<"AND THEY'RE OFF!!!!!"<<endl;
	int sum1=1,sum2=1;
	while(1)
	{
		 
		a=rand()%10+1;
		b=rand()%10+1;
		if(a>=1&&a<=5) sum1=sum1+3;
		else if(a>=6&&a<=7) sum1=sum1-6;
		else if(a>=8&&a<=10) sum1=sum1+1;
		if(sum1<1) sum1=1;
		if(sum1>=70) sum1=70;
		if(b>=1&&b<=2) sum2=sum2;
		else if(b>=3&&b<=4) sum2=sum2+9;
		else if(b==5) sum2+=12;
		else if(b>=6&&b<=8) sum2=sum2-1;
		else if(b>=9&&b<=10) sum2=sum2-2;
		
		if(sum2<1) sum2=1;
		if(sum2>=70) sum2=70;
		for(int i=1;i<=70;i++)
		{
			if(sum1==i&&sum1!=sum2) cout<<"T"<<" ";
			if(sum2==i&&sum2!=sum1) cout<<"H"<<" ";
			if(sum2==sum1==i) cout<<"OUCH!!!"<<" ";
			if(sum1!=i&&sum2!=i) cout<<"-"<<" ";
		}
		cout<<endl;
		if(sum1>=70||sum2>=70) break; 
	}
	if(sum1>=70&&sum2<70) cout<<"TORTOISE WINS!!!YAY!!!"<<endl;
	if(sum2>=70&&sum1<70) cout<<"Hare wins.Yuch."<<endl;
	if(sum1>=70&&sum2>=70) cout<<"It's a tie."<<endl;
   return 0;
   
}
