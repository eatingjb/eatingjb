/*FileName��T5_14.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Calculate total sales
*/
#include<iostream>
using namespace std;
int main()
{
    int i, j, k;
    cin >> i >> j;
    switch (i)
    {
    case 1:k = 2.98;
    case 2:k = 4.50;
    case 3:k = 9.98;
    case 4:k = 4.49;
    case 5:k = 6.87;
    default: break;
    }
    cout << j * k;
    return 0;
}
