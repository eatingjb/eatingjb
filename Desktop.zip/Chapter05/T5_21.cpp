/*FileName：T5_21.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Salary calculation
*/
#include<iostream>
using namespace std;
int main()
{
    cout<<"请输入你的工资代码"<<endl;
    int i,m;
    cin>>i;
    switch(i)
    {
        case 1:cout<<"输入固定工资"; break;
        case 2:cout<<"输入工作小时"; break;
        case 3:cout<<"输入销售毛利"; break;
        case 4:cout<<"输入产品件数和每件产品的固定金额"; break;
        default :break;
    }
   return 0;
}
