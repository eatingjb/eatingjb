/*FileName：T5_19.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Find the value of π
*/
#include<iostream>
#include<math.h>
using namespace std;
int main()
{
    double t = 1, sum = 0, a = 1,m,n=1;
    for (int i = 1; i <= 1000; i++)
    {
        m = 4 / n;
        a = a * (-1);
        t=t+2;
        n = t * a;
        sum = sum + m;
        cout << sum<<endl;
    }

    return 0;
}
