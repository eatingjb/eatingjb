/*FileName��T5_09.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Product of odd integers
*/
#include<iostream>
using namespace std;
int main()
{
   int sum=1;
   for(int i=1;i<=15;i++)
   {
       if(i%2==1) sum=sum*i;
   }
   cout<<sum;
   return 0;
}
