/*FileName��T5_22.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:De Morgan's law
*/
#include<iostream>
using namespace std;

int main()
{int x,y,a,b,i,j,g;
cin >> x>>y>>a>>b>>i>>j>>g;
if(!(x<5)&&!(y>=7)){
cout << "yes" << endl;}
else{cout<<"no"<<endl;}

if(!(x<5||y>=7)){
cout << "yes" << endl;}
else{cout<<"no"<<endl;}

  if(!(a==b)||!(g!=5)){
cout << "yes" << endl;}
else{cout<<"no"<<endl;}

if(!(a==b&&g!=5)){
cout << "yes" << endl;}
else{cout<<"no"<<endl;}

if(!((x<=8)&&(y>4))){
cout << "yes" << endl;}
else{cout<<"no"<<endl;}

if(!(x<=8)||!(y>4)){
cout << "yes" << endl;}
else{cout<<"no"<<endl;}

if(!((i>4)||(j<=6))){
cout << "yes" << endl;}
else{cout<<"no"<<endl;}

if(!(i>4)&&!(j<=6)){
cout << "yes" << endl;}
else{cout<<"no"<<endl;}
    return 0;
}
