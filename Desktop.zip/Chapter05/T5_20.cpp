/*FileName：T5_20.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Pythagorean triples
*/
#include<iostream>
using namespace std;
int main()
{
    for(int i=1;i<=500;i++)
    {
        for(int j=1;j<=i;j++)
        {
            for(int k=1;k<=j;k++)
                if(k*k+j*j==i*i)
            {
                cout<<"("<<k<<","<<j<<","<<i<<"),"
            }

        }
    }
   return 0;
}
