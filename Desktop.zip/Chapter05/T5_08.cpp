/*FileName��T5_8.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Find minimum value
*/
#include<iostream>
using namespace std;
int main()
{
   int n,t,min;
   cin>>n;
   for(int i=1;i<=n;i++)
   {
       cin>>t;
       if(i==1) min=t;
       else
       {
           if(t<min) min=t;
       }
   }
   cout<<min;
   return 0;
}
