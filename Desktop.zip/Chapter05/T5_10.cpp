/*FileName：T5_10.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Factorial
*/
#include<iostream>
using namespace std;
int main()
{
    cout<<"Êý×Ö\t"<<"½×³Ë"<<endl;
    int sum=1;
    for(int i=1;i<=5;i++)
    {
        for(int j=1;j<=i;j++)
        {
            sum=sum*j;
        }
        cout<<i<<"\t"<<sum<<endl;
        sum=1
    }
   return 0;
}
