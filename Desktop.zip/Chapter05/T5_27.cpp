/*FileName��T5_27.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:remove continue
*/
#include<iostream>
using namespace std;
int main()
{
       unsigned int count;
        for (count = 1; count <= 10; ++count)
        {
            if (count == 5)
            count++;
            cout << count << " ";
        }
        cout << "\nUsed continue to skip printing 5" << endl;
   return 0;
}
