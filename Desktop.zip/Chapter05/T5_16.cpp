/*FileName��T5_16.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Compound interest
*/

#include<iostream>
#include<iomanip>
#include<cmath>
using namespace std;
int main()
{
    double amount;
    double principal = 1000.0;
    double rate = 0.05;
    int a, b, c;
        cout << "year" << setw(21) << "Amount on deposit" << endl;
        cout << fixed << setprecision(2);
        for (unsigned int year = 1; year <= 10; ++year)
        {
            a = principal * 100;
            amount = a * pow(1.0 + rate, year);
            b = amount / 100;
            c = amount-(100*b);
            cout << setw(4) << year << setw(21) << b<<"."<<c << endl;
        }

    return 0;
}
