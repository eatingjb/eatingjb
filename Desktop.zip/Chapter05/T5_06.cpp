/*FileName��T5_06.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Integer averaging
*/
#include<iostream>
using namespace std;
int main()
{
    int n=0, t, sum = 0;
    cin >> t;
    for (int i = 1; ; i++)
    {
        if (t != 9999)
        {
            sum = sum + t;
            n = n + 1;
            cin >> t;
        }
        else break;
    }
    cout << sum / n;
    return 0;
}
