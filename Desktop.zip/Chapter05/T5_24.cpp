/*FileName£ºT5_24.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Modify the diamond pattern composed of asterisks
*/
#include<iostream>
using namespace std;
int main()
{
   cout<<"请输入1~19范围内的奇数:";
   int m;
   cin>>m;
   for (int i = 1; i <= (m+1)/2; i++)
    {
        for (int j = 1; j <= (m+1)/2 - i; j++)
        {
            cout << " ";
        }
        for (int k = 1; k <= 2 * i - 1; k++)
        {
            cout << "*";
        }
        cout << endl;
    }
    for (int i = 1; i <= (m-1)/2; i++)
    {
        for(int j = 1; j <= i; j++)
        {
        cout << " ";
        }
        for (int k = 1; k <= m - 2 * i; k++)
        {
            cout << "*";
        }
        cout << endl;
    }
   return 0;
}
