/*FileName��T5_25.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:remove break and continue
*/

#include<iostream>
    using namespace std;
    int main()
    {
        unsigned int count;
        for (count = 1; count <= 10; ++count)
        {
            if (count == 5)
            {
                cout << count << " ";
                count = 12;
            }
            else cout << count << " ";
        }
        cout << "\nBroke out of loop at count=" << count-8 << endl;
        return 0;
    }
