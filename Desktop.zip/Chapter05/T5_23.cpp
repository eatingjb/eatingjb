/*FileName��T5_23.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:
*/
#include<iostream>
using namespace std;
int main()
{
    for (int i = 1; i <= 5; i++)
    {
        for (int j = 1; j <= 5 - i; j++)
        {
            cout << " ";
        }
        for (int k = 1; k <= 2 * i - 1; k++)
        {
            cout << "*";
        }
        cout << endl;
    }
    for (int i = 1; i <= 4; i++)
    {
        for(int j = 1; j <= i; j++)
        {
        cout << " ";
        }
        for (int k = 1; k <= 9 - 2 * i; k++)
        {
            cout << "*";
        }
        cout << endl;
    }
    return 0;
}
