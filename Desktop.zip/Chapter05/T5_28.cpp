/*FileName：T5_28.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Twelve days of Christmas

*/
#include<iostream>
using namespace std;
int main()
{
    cout << "请输入天数" << endl;
    int n;
    cin >> n;
    switch (n)
    {
    case 1:cout << "On the first day of Christmas  my true love sent to me : A Partridge in a Pear Tree"; break;
    case 2:cout << "On the second day of Christmas my true love sent to me : Two Turtle Doves and a Partridge in a Pear Tree"; break;
    case 3:cout << "On the third day of Christmas my true love sent to me  Three French Hens Two Turtle Doves  and a Partridge in a Pear Tree; "; break;
    case 4:cout << "On the fourth day of Christmas my true love sent to me : Four Calling Birds   Three French Hens Two Turtle Doves  and a Partridge in a Pear Tree"; break;
    case 5:cout << "On the fifth day of Christmas my true love sent to me :Two Turtle Doves   and a Partridge in a Pear Tree"; break;
    case 6:cout << "On the sixth day of Christmas my true love sent to me : Six Geese a Laying Five Golden Rings  Four Calling Birds Three French Hens Two Turtle Doves  and a Partridge in a Pear Tree"; break;
    case 7:cout << "On the seventh day of Christmas my true love sent to me  Seven Swans a Swimming  Six Geese a Laying Five Golden Rings Four Calling Birds Three French Hens Two Turtle Doves and a Partridge in a Pear Tree"; break;
    case 8:cout << "On the eighth day of Christmas my true love sent to me : Eight Maids a Milking Seven Swans a Swimming  Six Geese a Laying Five Golden Rings Four Calling Birds Three French Hens Two Turtle Doves and a Partridge in a Pear Tree"; break;
    case 9:cout << "On the ninth day of Christmas my true love sent to me : Nine Ladies Dancing Eight Maids a Milking Seven Swans a Swimming Six Geese a Laying  Five Golden Rings Four Calling Birds Three French Hens Two Turtle Doves and a Partridge in a Pear Tree"; break;
    case 10:cout << "On the tenth day of Christmas my true love sent to me : Ten Lords a Leaping Nine Ladies Dancing Eight Maids a Milking Seven Swans a Swimming Six Geese a Laying Five Golden Rings Four Calling Birds Three French Hens Two Turtle Doves and a Partridge in a Pear Tree"; break;
    case 11:cout << "On the eleventh day of Christmas my true love sent to me : Eleven Pipers Piping Ten Lords a Leaping Nine Ladies Dancing Eight Maids a Milking Seven Swans a Swimming Six Geese a Laying Five Golden Rings Four Calling Birds Three French Hens Two Turtle Doves and a Partridge in a Pear Tree"; break;
    case 12:cout << "On the twelfth day of Christmas my true love sent to me : 12 Drummers Drumming Eleven Pipers Piping Ten Lords a Leaping Nine Ladies Dancing Eight Maids a Milking Seven Swans a Swimming Six Geese a Laying Five Golden Rings Four Calling Birds Three French Hens Two Turtle Doves and a Partridge in a Pear Tree"; break;
    }
    return 0;
}


