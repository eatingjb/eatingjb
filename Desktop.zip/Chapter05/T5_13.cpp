/*FileName：T5_13.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Bar chart
*/
#include<iostream>
using namespace std;
int main()
{
    int  n,k ;
    for (int i = 1; i <= 5; i++)
    {
        cin >> n;
        for (int k = 1; k <= n; k++)
        {
            cout << "*";
        }
        cout << endl;
    }
    return 0;
}
