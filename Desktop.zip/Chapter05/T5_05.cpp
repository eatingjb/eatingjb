/*FileName：T5_05.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:Mar 11,2022
Function:Integer summation
*/
#include<iostream>
using namespace std;
int main()
{
    int n,t,sum=0;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        cin >> t;
        sum = sum + t;
    }
    cout << t;
    return 0;
}
