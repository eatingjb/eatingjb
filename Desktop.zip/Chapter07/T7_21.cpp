/*FileName��T7_21.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Sales summary
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a[5][4],p=0,sum=0;
    cout<<"������ÿλ����Աÿ�ֲ�Ʒ�����ܶ�"<<endl;
    for(int i=0;i<5;i++)
       for(int j=0;j<4;j++)
       {
       	cin>>a[i][j];
	   }
	   cout<<"     ";
	for(int i=1;i<=4;i++)
	{
		cout<<"����Ա"<<i<<"\t";
	}
	cout<<"�ܶ�";
	cout<<endl;
	for(int i=0;i<5;i++)
	{
		cout<<"��Ʒ"<<i+1<<"\t"; 
		for(int j=0;j<4;j++)
		{
			cout<<a[i][j]<<"\t"; 
		}
		for(int k=0;k<4;k++)
		{
			sum+=a[p][k];
			
		}
		cout<<sum<<"\t";
		p+=1;
		sum=0;
		cout<<endl;
	}
	sum=0;
	p=0;
	
	for(int s=1;s<=4;s++)
	{
		for(int i=0;i<5;i++)
	    {
		   sum+=a[i][p];
	    }
	    cout<<"\t"<<sum;
	    sum=0;
	    p+=1;
	} 
	
   return 0;
}
