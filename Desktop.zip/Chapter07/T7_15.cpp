/*FileName��T7_15.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Two-dimensional array object initialization
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
	const int row=3,column=4;
	int sales[row][column];
	for(size_t row=0;row<sales.size();row++)
	{
		for(size_t column=0;column<sales[row].size();column++)
		{
			sales[row][column]=0;
		}
	}
   return 0;
}

