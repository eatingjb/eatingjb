/*FileName��T7_10.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Salesperson salary range
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
	   int n;
	   cin>>n;
	   double *a=new double[n];
	   double *b=new double[n];
	   int sum1=0,sum2=0,sum3=0,sum4=0,sum5=0,sum6=0,sum7=0,sum8=0,sum9=0;
	   for(int i=0;i<n;i++)
	   {
	   	   cin>>a[i];
	   	   b[i]=a[i]*0.09+200;
	   	   if(b[i]>=200&&b[i]<=299) sum1+=1;
	   	   if(b[i]>=300&&b[i]<=399) sum2+=1;
	   	   if(b[i]>=400&&b[i]<=499) sum3+=1;
	   	   if(b[i]>=500&&b[i]<=599) sum4+=1;
	   	   if(b[i]>=600&&b[i]<=699) sum5+=1;
	   	   if(b[i]>=700&&b[i]<=799) sum6+=1;
	   	   if(b[i]>=800&&b[i]<=899) sum7+=1;
	   	   if(b[i]>=900&&b[i]<=999) sum8+=1;
	   	   if(b[i]>=1000) sum9+=1;
		} 
	    cout<<"200~299��Ԫ��"<<sum1<<"��"<<endl; 
	    cout<<"300~399��Ԫ��"<<sum2<<"��"<<endl;
		cout<<"400~499��Ԫ��"<<sum3<<"��"<<endl;  
		cout<<"500~599��Ԫ��"<<sum4<<"��"<<endl; 
		cout<<"600~699��Ԫ��"<<sum5<<"��"<<endl; 
		cout<<"700~799��Ԫ��"<<sum6<<"��"<<endl; 
		cout<<"800~899��Ԫ��"<<sum7<<"��"<<endl; 
		cout<<"900~999��Ԫ��"<<sum8<<"��"<<endl; 
		cout<<"1000��Ԫ���ϣ�"<<sum9<<"��"<<endl; 
   return 0;
}
