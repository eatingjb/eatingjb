/*FileName��T7_32.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Find the minimum value
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int arr[10],min;
	for(int i=0;i<10;i++)
	{
		cin>>arr[i];
	}
	for(int i=0;i<10;i++)
	{
		if(i==0) min=arr[i];
		else
		{
			arr[i]<min?min=arr[i]:1;
		}
	}
	cout<<min;
   return 0;
}
