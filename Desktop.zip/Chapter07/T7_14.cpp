/*FileName��T7_14.cpp
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Deduplication with vector objects
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
	vector<int> vec;
	int x; 
	for(int i=0;i<20;i++)
	{
		cin>>x;
		vec.push_back(x);
		for(int j=0;j<vec.size()-1;j++)
		{
			if(x==vec[j]) vec.pop_back();
		}
	}
	for(int i=0;i<10;i++)
	cout<<vec[i]<<" ";
   return 0;
}
