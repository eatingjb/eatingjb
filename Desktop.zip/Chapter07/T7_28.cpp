/*FileName��T7_28.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:palindrome
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
	
	int n,s=0,t;
	 cin>>n;
	 n=t;
	 while(t>0)
	 {
	 	s=s*10+t%10;
	 	t=t/10;
	 }
	 if(s==n) cout<<"ture"<<endl;
	 else cout<<"false"<<endl; 
   return 0;
}
