/*FileName��T7_27.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Elatossens sifting
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int arr[1000];
	for(int i=0;i<1000;i++)
	{
		arr[i]=1;
	}
	for(int i=3;i<1000;i++)
	{
		for(int j=2;j<i-1;j++)
		{
			if(0==i%j) arr[i]=0;
		}
	}
	for(int i=2;i<1000;i++)
	{
		if(arr[i]!=0) cout<<i<<" ";
	}
   return 0;
}
