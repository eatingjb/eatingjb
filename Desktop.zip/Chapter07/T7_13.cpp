/*FileName��T7_13.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Deduplication with array objects
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
	int a[20];
	for(int i=0;i<20;i++)
	{
		int p=0;
		cin>>a[i];
		if(i==0) cout<<a[i]<<" ";
		else
		{
			for(int j=0;j<i;j++)
		    {
			   if(a[i]==a[j]) p=1;
		    }
		    if(p==0) cout<<a[i]<<" ";
		} 
	 } 
   return 0;
}
