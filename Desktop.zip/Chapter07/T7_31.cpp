/*FileName��T7_31.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Reverses the print string
*/
#include<bits/stdc++.h>
using namespace std;
int main()
{
	string str;
	cin>>str;
	reverse(str.begin(),str.end());
	cout<<str;
   return 0;
}
