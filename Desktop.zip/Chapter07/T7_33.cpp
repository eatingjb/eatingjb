/*FileName��T7_33.cpp 
Author:Shen Yiting
E-mail:2728586554@qq.com
Time:April 4,2022
Function:Maze traversal
*/
#include <iostream>

using namespace std;
int mainexe(char a[12][12],int i,int j);
void allll(char a[12][12],int i,int j);
void allll(char a[12][12],int i,int j)
{
    a[i][j]='x';
    for(int q=0; q<12; q++)
    {
        for(int w=0; w<12; w++)
        {
            cout<<a[q][w]<<" ";
        }
        cout<<endl;

    }
    cout<<endl;

}
int mainexe(char a[12][12],int i,int j)
{
    int k=1,l=11;
    int direction=1;
    while(i!=k||j!=l)
    {
        if(direction==1)
        {
            if(a[i+1][j]=='.')
            {
                a[i][j]='.';
                i++;
                allll(a,i,j);
                direction=2;
                continue;
            }
            else if(a[i][j+1]=='.')
            {
                a[i][j]='.';
                j++;

                allll(a,i,j);
                continue;
            }
            else if(a[i-1][j]=='.')
            {
                a[i][j]='.';
                i--;
                direction=4;
                allll(a,i,j);
                continue;
            }
            else
            {
                a[i][j]='.';
                j--;
                direction=3;
                allll(a,i,j);
                continue;
            }
        }
        if(direction==2)
        {
            if(a[i][j-1]=='.')
            {
                a[i][j]='.';
                j--;
                allll(a,i,j);
                direction=3;
                continue;
            }
            else if(a[i+1][j]=='.')
            {
                a[i][j]='.';
                i++;

                allll(a,i,j);
                continue;
            }
            else if(a[i][j+1]=='.')
            {
                a[i][j]='.';
                j++;
                direction=1;
                allll(a,i,j);
                continue;
            }
            else
            {
                a[i][j]='.';
                i--;
                direction=4;
                allll(a,i,j);
                continue;
            }
        }

        if(direction==3)
        {
            if(a[i-1][j]=='.')
            {
                a[i][j]='.';
                i--;
                allll(a,i,j);
                direction=4;
                continue;
            }
            else if(a[i][j-1]=='.')
            {
                a[i][j]='.';
                j--;

                allll(a,i,j);
                continue;
            }
            else if(a[i+1][j]=='.')
            {
                a[i][j]='.';
                i++;
                direction=2;
                allll(a,i,j);
                continue;
            }
            else
            {
                a[i][j]='.';
                j++;
                direction=1;
                allll(a,i,j);
                continue;
            }
        }

        if(direction==4)
        {
            if(a[i][j+1]=='.')
            {
                a[i][j]='.';
                j++;
                allll(a,i,j);
                direction=1;
                continue;
            }
            else if(a[i-1][j]=='.')
            {
                a[i][j]='.';
                i--;

                allll(a,i,j);
                continue;
            }
            else if(a[i][j-1]=='.')
            {
                a[i][j]='.';
                j--;
                direction=3;
                allll(a,i,j);
                continue;
            }
            else
            {
                a[i][j]='.';
                i++;
                direction=2;
                allll(a,i,j);
                continue;
            }
        }
    }




}
int main()
{
    char a[12][12]=
    {
        {'#','#','#','#','#','#','#','#','#','#','#','#'},
        {'#','.','.','.','#','.','.','.','.','.','.','.'},
        {'.','.','#','.','#','.','#','#','#','#','.','#'},
        {'#','#','#','.','#','.','.','.','.','#','.','#'},
        {'#','.','.','.','.','#','#','#','.','#','.','#'},
        {'#','#','#','#','.','#','.','#','.','#','.','#'},
        {'#','.','.','#','.','#','.','#','.','#','.','#'},
        {'#','#','.','#','.','#','.','#','.','#','.','#'},
        {'#','.','.','.','.','.','.','.','.','#','.','#'},
        {'#','#','#','#','#','#','.','#','#','#','.','#'},
        {'#','.','.','.','.','.','.','#','.','.','.','#'},
        {'#','#','#','#','#','#','#','#','#','#','#','#'}
    };
    int i=2,j=0;

    mainexe(a,i,j);


    return 0;
}

